from xumes.game_module.implementations.pygame_impl.pygame_event_factory import PygameEventFactory
from xumes.game_module.implementations.pygame_impl.pygame_events import (
    Up,
    Down,
    Left,
    Right,
    Space
)
