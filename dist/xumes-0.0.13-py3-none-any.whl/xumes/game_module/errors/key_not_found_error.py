class KeyNotFoundError(Exception):
    pass
